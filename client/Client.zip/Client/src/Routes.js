import LoginPage from "./Pages/LoginPage";
import SignupPage from "./Pages/SignupPage";
export{
    LoginPage,
    SignupPage
}