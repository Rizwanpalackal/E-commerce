import React from 'react'
import Signup from '../Components/Signup/Signup'

const SignupPage = () => {
  return (
    <div><Signup/></div>
  )
}

export default SignupPage